package com.example.aprendeudbapp.utils

fun validarContrasena(pass: String): Boolean {
    val regex = Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#\$%^&*]).{8,}\$")
    return regex.matches(pass)
}
