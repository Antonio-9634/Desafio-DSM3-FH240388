package com.example.aprendeudbapp.data.model

data class Resource(
    val id: String,
    val titulo: String,
    val descripcion: String,
    val tipo: String,
    val enlace: String,
    val imagen: String
)
