package com.example.aprendeudbapp.data.repository

import com.example.aprendeudbapp.data.api.ApiService
import com.example.aprendeudbapp.data.model.Resource
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ResourceRepository {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://6732c07da042ab85d11b47ef.mockapi.io/api/") // MockAPI activa
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val api = retrofit.create(ApiService::class.java)

    fun getRecursos() = api.getRecursos()
    fun addRecurso(r: Resource) = api.addRecurso(r)
    fun updateRecurso(id: String, r: Resource) = api.updateRecurso(id, r)
    fun deleteRecurso(id: String) = api.deleteRecurso(id)
}
