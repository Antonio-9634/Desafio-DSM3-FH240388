<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical" android:gravity="center"
    android:padding="24dp" android:background="@color/black"
    android:layout_width="match_parent" android:layout_height="match_parent">

    <EditText android:id="@+id/etUser" android:hint="Usuario" android:textColor="@color/white"
        android:backgroundTint="@color/teal_200" android:layout_width="match_parent"
        android:layout_height="wrap_content" />

    <EditText android:id="@+id/etPassword" android:hint="Contraseña" android:inputType="textPassword"
        android:textColor="@color/white" android:backgroundTint="@color/teal_200"
        android:layout_width="match_parent" android:layout_height="wrap_content" />

    <Button android:id="@+id/btnLogin" android:text="Iniciar Sesión"
        android:layout_marginTop="16dp" android:layout_width="match_parent"
        android:layout_height="wrap_content" />

    <TextView android:id="@+id/tvRegister" android:text="¿No tienes cuenta? Regístrate"
        android:textColor="@color/teal_200" android:layout_marginTop="12dp"
        android:layout_width="wrap_content" android:layout_height="wrap_content" />
</LinearLayout>
