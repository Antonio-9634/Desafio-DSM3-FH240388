package com.example.aprendeudbapp.ui.main

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aprendeudbapp.data.model.Resource
import com.example.aprendeudbapp.data.repository.ResourceRepository
import com.example.aprendeudbapp.databinding.ActivityMainBinding
import com.example.aprendeudbapp.ui.adapter.ResourceAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repo = ResourceRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        cargarRecursos()
        binding.swipeRefresh.setOnRefreshListener { cargarRecursos() }
        binding.fabAdd.setOnClickListener { mostrarAgregarDialog() }
    }

    private fun cargarRecursos() {
        binding.swipeRefresh.isRefreshing = true
        repo.getRecursos().enqueue(object : Callback<List<Resource>> {
            override fun onResponse(call: Call<List<Resource>>, response: Response<List<Resource>>) {
                binding.swipeRefresh.isRefreshing = false
                if (response.isSuccessful) {
                    binding.recyclerView.adapter = ResourceAdapter(response.body()!!, repo)
                }
            }
            override fun onFailure(call: Call<List<Resource>>, t: Throwable) {
                binding.swipeRefresh.isRefreshing = false
                Toast.makeText(this@MainActivity, "Error al conectar con API", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun mostrarAgregarDialog() {
        val dialogView = layoutInflater.inflate(com.example.aprendeudbapp.R.layout.dialog_add, null)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        builder.setPositiveButton("Guardar") { _, _ ->
            val titulo = dialogView.findViewById<android.widget.EditText>(com.example.aprendeudbapp.R.id.etTitulo).text.toString()
            val desc = dialogView.findViewById<android.widget.EditText>(com.example.aprendeudbapp.R.id.etDescripcion).text.toString()
            val tipo = dialogView.findViewById<android.widget.EditText>(com.example.aprendeudbapp.R.id.etTipo).text.toString()
            val enlace = dialogView.findViewById<android.widget.EditText>(com.example.aprendeudbapp.R.id.etEnlace).text.toString()
            val img = dialogView.findViewById<android.widget.EditText>(com.example.aprendeudbapp.R.id.etImagen).text.toString()
            val nuevo = Resource("", titulo, desc, tipo, enlace, img)
            repo.addRecurso(nuevo).enqueue(object : Callback<Resource> {
                override fun onResponse(call: Call<Resource>, response: Response<Resource>) {
                    Toast.makeText(this@MainActivity, "Recurso agregado", Toast.LENGTH_SHORT).show()
                    cargarRecursos()
                }
                override fun onFailure(call: Call<Resource>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Error al agregar", Toast.LENGTH_SHORT).show()
                }
            })
        }
        builder.setNegativeButton("Cancelar", null)
        builder.show()
    }
}
