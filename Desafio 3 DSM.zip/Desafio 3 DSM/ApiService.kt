package com.example.aprendeudbapp.data.api

import com.example.aprendeudbapp.data.model.Resource
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("recursos")
    fun getRecursos(): Call<List<Resource>>

    @POST("recursos")
    fun addRecurso(@Body recurso: Resource): Call<Resource>

    @PUT("recursos/{id}")
    fun updateRecurso(@Path("id") id: String, @Body recurso: Resource): Call<Resource>

    @DELETE("recursos/{id}")
    fun deleteRecurso(@Path("id") id: String): Call<Void>
}
