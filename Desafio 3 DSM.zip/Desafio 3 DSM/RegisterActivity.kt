package com.example.aprendeudbapp.ui.register

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.aprendeudbapp.databinding.ActivityRegisterBinding
import com.example.aprendeudbapp.utils.validarContrasena

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {
            val pass = binding.etPassword.text.toString()
            if (validarContrasena(pass)) {
                Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Contraseña no válida", Toast.LENGTH_LONG).show()
            }
        }
    }
}
